﻿using UnityEngine;

public class Circle : MonoBehaviour
{
    public float duration;
    public float endRadius;
    private LineRenderer line;
    public int segments;
    public float startRadius;
    private float startTime;
    private float radius;
    public Color circleColor;
    private Color transparentColor;

    private void Start()
    {
        line = gameObject.GetComponent<LineRenderer>();

        line.SetVertexCount(segments + 1);
        line.useWorldSpace = false;
        CreatePoints(startRadius);
        startTime = Time.time;
    }

    private void Update()
    {
        radius = Mathf.Lerp(startRadius, endRadius, (Time.time - startTime)/duration);
        if (radius < endRadius)
        {
            CreatePoints(radius);

            transparentColor = new Color(0,0,0,0);
            float factor = .8f + .2f * (Time.time - startTime) / duration;
            var lerpedColor = Color.Lerp(circleColor, transparentColor, factor);
            line.SetColors(lerpedColor, lerpedColor);
        }
        else
            Destroy(gameObject);
    }


    private void CreatePoints(float radius)
    {
        float x;
        float y;
        float z = 0f;

        float angle = 20f;

        for (int i = 0; i < (segments + 1); i++)
        {
            x = Mathf.Sin(Mathf.Deg2Rad*angle)*radius;
            y = Mathf.Cos(Mathf.Deg2Rad*angle)*radius;

            line.SetPosition(i, new Vector3(x, y, z));

            angle += (360f/segments);
        }
    }
}