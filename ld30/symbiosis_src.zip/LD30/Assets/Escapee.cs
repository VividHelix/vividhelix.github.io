﻿using UnityEngine;
using System.Collections;

public class Escapee : MonoBehaviour {
    private float blinkStartTime = -100;
    private Color blinkColor;
    private tk2dBaseSprite sprite;
    private float blinkDuration = .5f;
    private Color initialColor;
    private GameMainLoop gameMain;

    // Use this for initialization
	void Start () {
        Light2D.RegisterEventListener(LightEventListenerType.OnEnter, OnLightEnter);
        Light2D.RegisterEventListener(LightEventListenerType.OnExit, OnLightExit);
	    sprite = GetComponent<tk2dBaseSprite>();
	    initialColor = sprite.color;
	    gameMain = GameObject.Find("GameMain").GetComponent<GameMainLoop>();
	}

    void OnDestroy()
    {
        /* (!) Make sure you unregister your events on destroy. If you do not
         * you might get strange errors (!) */

        Light2D.UnregisterEventListener(LightEventListenerType.OnEnter, OnLightEnter);
        Light2D.UnregisterEventListener(LightEventListenerType.OnExit, OnLightExit);
    }

	// Update is called once per frame
	void Update ()
	{
	    var elapsed = Time.time - blinkStartTime;
        if (elapsed > blinkDuration)
            return;
	    sprite.color = Color.Lerp(blinkColor, initialColor, elapsed/blinkDuration);
	}

    void OnLightEnter(Light2D l, GameObject g)
    {
        var sprite = g.GetComponent<tk2dBaseSprite>();
        if (sprite != null)
        {
            var guard = l.GetComponentInParent<GuardBehavior>();
            if (guard != null)
            {
                guard.UpdateLightColor(true);
                l.LightColor = Color.magenta;
                gameMain.LevelFailed();
            }
            else
            {
                gameMain.LevelSucceeded(g.GetComponent<PhysicsPlayerTester>().secondary, true);
            }

        }
    }

    void OnLightExit(Light2D l, GameObject g)
    {
        var sprite = g.GetComponent<tk2dBaseSprite>();
        if (sprite != null)
        {
            var guard = l.GetComponentInParent<GuardBehavior>();
            if (guard != null)
            {
                l.GetComponentInParent<GuardBehavior>().UpdateLightColor(false);
            }
            else if (g.GetComponent<PhysicsPlayerTester>()!=null)
            {
                gameMain.LevelSucceeded(g.GetComponent<PhysicsPlayerTester>().secondary, false);
            }
        }
    }


    public void BlinkTo(Color color)
    {
        this.blinkStartTime = Time.time;
        this.blinkColor = color;
        sprite.color = blinkColor;
    }
}
