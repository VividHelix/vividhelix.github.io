﻿using UnityEngine;

public class GameMainLoop : MonoBehaviour
{
    public GameObject[] Levels;
    private int currentLevelIndex;
    private GameObject currentLevelObject;
    private bool primarySucceeded;
    private bool secondarySucceeded;
    private tk2dTextMesh textMesh;
    private State state = State.OTHER;
    private bool starting;
    public Color colorSuccess;
    public Color colorPrimarySuccess;
    public Color colorSecondarySuccess;
    public Color colorNone;

    enum State
    {
        OTHER, FAILED, PASSED
    }

    // Use this for initialization
    private void Start()
    {
        textMesh = GetComponentInChildren<tk2dTextMesh>();
        DisplayText("PRESS ANY KEY");
        starting = true;
    }

    public void Update()
    {
        if (starting && Input.anyKeyDown)
        {
            starting = false;
            Destroy(transform.FindChild("ControlsLeft").gameObject);
            Destroy(transform.FindChild("ControlsRight").gameObject);
            LoadLevel();
        }
    }

    private void HideText()
    {
        DisplayText("");
    }

    private void DisplayText(string text)
    {
        textMesh.text = text;
        textMesh.Commit();
    }


    private void LoadLevel()
    {
        DestroyCurrentLevel();
        DisplayText(Levels[currentLevelIndex].name);
        Invoke("LoadCurrentLevel",1);
    }

    private void LoadCurrentLevel()
    {
        state = State.OTHER;
        HideText();
        currentLevelObject = (GameObject) Instantiate(Levels[currentLevelIndex], Vector3.zero, Quaternion.identity);
        currentLevelObject.GetComponentInChildren<tk2dTileMap>().ForceBuild();
        GameObject.Find("A*").GetComponent<AstarPath>().Scan();
    }

    private void DestroyCurrentLevel()
    {
        primarySucceeded = false;
        secondarySucceeded = false;
        if (currentLevelObject != null)
        {
            Destroy(currentLevelObject);
            currentLevelObject = null;
        }
    }

    private void DisableCurrentLevel()
    {
        if (currentLevelObject != null)
        {
            foreach (var component in currentLevelObject.GetComponentsInChildren<PhysicsPlayerTester>())
                Destroy(component);
            foreach (var component in currentLevelObject.GetComponentsInChildren<GuardBehavior>())
                Destroy(component);
        }
    }

    public void LevelFailed()
    {
        if (state != State.OTHER)
            return;
        state = State.FAILED;
        DisplayText("LEVEL FAILED");
        DisableCurrentLevel();
        Invoke("LoadLevel", 1);
    }

    public void LevelSucceeded(bool primary, bool succeeded)
    {
        if (primary)
            primarySucceeded = succeeded;
        else
            secondarySucceeded = succeeded;

        Color lightColor;
        if (primarySucceeded && secondarySucceeded)
            lightColor = colorSuccess;
        else if (primarySucceeded)
            lightColor = colorPrimarySuccess;
        else if (secondarySucceeded)
            lightColor = colorSecondarySuccess;
        else
            lightColor = colorNone;
        currentLevelObject.transform.FindChild("FinishLight").GetComponent<Light2D>().LightColor = lightColor;

        if (primarySucceeded && secondarySucceeded)
        {
            LevelPassed();
        }
    }

    private void LevelPassed()
    {
        if (state != State.OTHER)
            return;
        state = State.PASSED;
        currentLevelIndex++;
        DisplayText("LEVEL PASSED");
        DisableCurrentLevel();
        if (currentLevelIndex >= Levels.Length)
            Invoke("GameFinished", 1);
        else
            Invoke("LoadLevel", 1);
    }

    public void GameFinished()
    {
        DestroyCurrentLevel();
        DisplayText("CONGRATULATIONS!");
    }
}