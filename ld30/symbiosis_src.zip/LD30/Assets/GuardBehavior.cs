﻿using Pathfinding;
using UnityEngine;
using System.Collections;

public class GuardBehavior : MonoBehaviour
{

    public Escapee actor;
    private Seeker seeker;
    private Path path;
    public bool left;
    public GameObject ripplePrefab;
    public string[] spriteNames;

    //The AI's speed per second
    public float speed = 100;

    //The max distance from the AI to a waypoint for it to continue to the next waypoint
    public float nextWaypointDistance = 3;

    private int currentWaypoint = 0;
    private CharacterController2D controller;
    private Light2D light2D;
    private int redLayer;
    private int orangeLayer;
    private tk2dBaseSprite sprite;
    public Color detectedLightColor;
    public Color idleLightColor;
    public Color alertedLightColor;
    private int callCount = 1;

    void Start ()
	{
	    seeker = GetComponent<Seeker>();
	    controller = GetComponent<CharacterController2D>();
        light2D = GetComponentInChildren<Light2D>();
        light2D.EnableEvents = true;
        UpdateLightColor(false);
        redLayer = LayerMask.NameToLayer("Red");
        orangeLayer = LayerMask.NameToLayer("Orange");
        sprite = GetComponent<tk2dBaseSprite>();
	}

    private void Update()
    {
        if (Input.GetKeyDown(left ? KeyCode.RightShift : KeyCode.Space))
        {
            if (callCount<=0)
                return;
            callCount--;
            var circle = ((GameObject) Instantiate(ripplePrefab, actor.gameObject.transform.position, Quaternion.identity)).GetComponent<Circle>();
            circle.gameObject.layer = actor.gameObject.layer == redLayer ? orangeLayer : redLayer;
            circle.circleColor = sprite.color;
            
            seeker.StartPath(transform.position, actor.transform.position, PathComputed);
            actor.BlinkTo(sprite.color);
        }
}

    private void PathComputed(Path p)
    {
        if (!p.error)
        {
            path = p;
            currentWaypoint = 0;
            if (path.vectorPath[currentWaypoint] != transform.position)
                light2D.LookAt(path.vectorPath[currentWaypoint]);
            UpdateLightColor(false);
        }
    }

    public void FixedUpdate()
    {
        if (path == null || currentWaypoint >= path.vectorPath.Count)
            return;

        var dir = (path.vectorPath[currentWaypoint] - transform.position).normalized;
        dir *= speed * Time.fixedDeltaTime;
        controller.move(dir);
        SetSpriteByDirection(dir);

        //Check if we are close enough to the next waypoint
        //If we are, proceed to follow the next waypoint
        if (Vector3.Distance(transform.position, path.vectorPath[currentWaypoint]) < nextWaypointDistance)
        {
            currentWaypoint++;
            if (currentWaypoint < path.vectorPath.Count && path.vectorPath[currentWaypoint] != transform.position)
                light2D.LookAt(path.vectorPath[currentWaypoint]);
            else
            {
                path = null;
                UpdateLightColor(false);
                light2D.transform.Rotate(0,0,180);
            }
        }
    }

    private void SetSpriteByDirection(Vector3 dir)
    {
        if (IsLeft(dir))
            sprite.SetSprite(spriteNames[2]);
        else if (IsRight(dir))
            sprite.SetSprite(spriteNames[3]);
        else if (IsDown(dir))
            sprite.SetSprite(spriteNames[0]);
        else if (IsUp(dir))
            sprite.SetSprite(spriteNames[1]);
    }

    private static bool IsDown(Vector3 dir)
    {
        return dir.y<0 && !IsSideways(dir);
    }

    private static bool IsUp(Vector3 dir)
    {
        return dir.y>0 && !IsSideways(dir);
    }

    private static bool IsLeft(Vector3 dir)
    {
        return dir.x<0 && IsSideways(dir);
    }

    private static bool IsRight(Vector3 dir)
    {
        return dir.x>0 && IsSideways(dir);
    }

    private static bool IsSideways(Vector3 dir)
    {
        return Mathf.Abs(dir.x)>Mathf.Abs(dir.y);
    }

    public void UpdateLightColor(bool detected)
    {
        light2D.LightColor = detected ? detectedLightColor : (path == null ? idleLightColor : alertedLightColor);
    }
}
